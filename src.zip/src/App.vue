<template>
  <div id="app">
        <div class="wrapper">
        <Clock />
        <Login />
        <Quiz />
        <Table ref="table"/>
        <TableForm v-on:addEntry="addPersonToTable"/>
        
        <div id="order-list-box" class="box">
            
        </div>
        <div id="search-list-box" class="box">
            
        </div>
        <div id="search-grid-box" class="box">
            
        </div>
        <div id="eight-ball-box" class="box">
            
        </div>
    </div>
  </div>
</template>

<script>
import Clock from './components/Clock'
import Login from './components/Login'
import Quiz from './components/Quiz'
import Table from './components/Table'
import TableForm from './components/TableForm'
export default {
  name: 'App',
  components: {
    Clock,
    Login,
    Quiz,
    Table,
    TableForm
  },
  methods: {
    addPersonToTable(person) {
      console.log(this.$refs);
      this.$refs.table.addRow(person);
    }
  }
}
</script>

<style>
  @import "reset.css";

  button {
    cursor: pointer;
}


.wrapper{
    width: 1000px;
    height: 1000px;
    margin: 0 auto;
    padding: 30px 0;
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    grid-template-rows: 1fr 1fr 1fr;
    grid-template-areas:
    "one two three"
    "four five six"
    "seven eight nine";
    grid-gap: 10px;
}

.box {
    height: 350px;
    background-color: gray;
    border: black 1px solid;
}

.wrapper Clock{
    grid-area: one;
}
.wrapper #login-box{
    grid-area: two;
}
.wrapper #quiz-box{
    grid-area: three;
}
.wrapper #table-box{
    grid-area: four;
}
.wrapper #add-row-box{
    grid-area: five;
}
.wrapper #order-list-box{
    grid-area: six;
}
.wrapper #search-list-box{
    grid-area: seven;
}
.wrapper #search-grid-box{
    grid-area: eight;
}
.wrapper #eight-ball-box{
    grid-area: nine;
}

</style>
